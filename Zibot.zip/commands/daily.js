const { EmbedBuilder } = require("discord.js");
const db = require("./../mongoDB");
const client = require('../bot');
const { rank } = require("../events/Zibot/ZilvlSys");
const { msToTime } = require("../events/Zibot/ZiFunc");

module.exports = {
  name: "daily",
  description: "View profile.",
  options: [],
  cooldown: 3,
  dm_permission: true,
  run: async (lang, interaction) => {

    let messages = await ZifetchInteraction(interaction);

    let userDB = await db.ZiUser.findOne({ userID: interaction.user.id }).catch(e => { })

    const embed = new EmbedBuilder()
      .setTimestamp()
      .setFooter({ text: `${lang?.RequestBY} ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })

    if (userDB?.claimcheck !== null && 86400000 - (Date.now() - userDB?.claimcheck) > 0) {
      const timeleft = msToTime(86400000 - (Date.now() - userDB?.claimcheck))
      embed.setColor("#1a81e8")
      embed.setDescription(lang?.claimfail.replace("houurss", timeleft));
    } else {
      embed.setColor(lang?.COLOR || client.color);
      await rank({ user: interaction.user, lvlAdd: 49 })
      await db.ZiUser.updateOne({ userID: interaction.user.id }, {
        $set: { claimcheck: Date.now() }
      }, { upsert: true });

      let userDB2 = await db.ZiUser.findOne({ userID: interaction.user.id }).catch(e => { })
      embed.setDescription(`${lang?.claimsuss} lvl: ${userDB2?.lvl} xp: ${userDB2?.Xp}/${userDB2?.lvl * 50 + 1}`);
    }
    return messages?.edit({ embeds: [ embed ] }).catch(e => interaction?.channel?.send({ embeds: [ embed ] }))

  },
};
