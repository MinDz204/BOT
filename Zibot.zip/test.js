
// (async()=>{
// const search = await googleThisApi.image("cat", { safe: false });

const { Zicrop } = require("./events/Zibot/ZiFunc")

// const attachment = [ ];
// for (let k = 0; k < 10; k++) {
//     const data = search[k];
//     if (
//         !data?.url
//     ) {
//         continue;
//     }
//     console.log(data.url)
// }
// })()

console.log(Zicrop("ZsearchrefZi=undefined genshin impact wallpaper undefined"))