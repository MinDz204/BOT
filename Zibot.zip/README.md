# Zibot
 Ziji discord bot
npm config set strict-ssl=false